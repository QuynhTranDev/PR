package com.example.asm.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

//import com.example.asm.Manager.CartManager;
import com.example.asm.Model.Product;
import com.example.asm.R;
import com.squareup.picasso.Picasso;

public class ProductDetailFragment extends Fragment {

    private ImageView ivBack, ivProductImage;
    private TextView tvName, tvDescription, tvPrice;
//    private Button btnAddToCart;
//    private CartManager cartManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_product_detail, container, false);

        ivBack = view.findViewById(R.id.ivBack);
        ivProductImage = view.findViewById(R.id.ivProductImage);
        tvName = view.findViewById(R.id.tvName);
        tvDescription = view.findViewById(R.id.tvDescription);
        tvPrice = view.findViewById(R.id.tvPrice);
//        btnAddToCart = view.findViewById(R.id.btnAddToCart);
//        cartManager = new CartManager(getContext());

        if (getArguments() != null) {
            Product product = (Product) getArguments().getSerializable("product");
            if (product != null) {
                tvName.setText(product.getName());
                tvDescription.setText(product.getDescription());
                tvPrice.setText(String.format("%,.0f đ", product.getPrice()));
                Picasso.get().load(product.getImageUrl()).into(ivProductImage);
            }
        }

        ivBack.setOnClickListener(v -> getParentFragmentManager().popBackStack());

//        btnAddToCart.setOnClickListener(v -> {
//            Product product = (Product) getArguments().getSerializable("product");
//            if (product != null) {
//                cartManager.addToCart(product);
//                Toast.makeText(getActivity(), "Added to cart", Toast.LENGTH_SHORT).show();
//            }
//        });

        return view;
    }

    public static ProductDetailFragment newInstance(Product product) {
        ProductDetailFragment fragment = new ProductDetailFragment();
        Bundle args = new Bundle();
        args.putSerializable("product", product);
        fragment.setArguments(args);
        return fragment;
    }
}
