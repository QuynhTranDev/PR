package com.example.asm.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.asm.Client.RetrofitClient;
import com.example.asm.Interface.Api;
import com.example.asm.Model.Product;
import com.example.asm.R;
import com.example.asm.Adapter.ProductAdapter;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ViewProductsFragment extends Fragment {

    private RecyclerView recyclerView;
    private ProductAdapter productAdapter;
    private List<Product> productList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_view_products, container, false);

        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        productList = new ArrayList<>();
        productAdapter = new ProductAdapter(productList);
        recyclerView.setAdapter(productAdapter);

        fetchProducts();

        return view;
    }

    private void fetchProducts() {
        JsonObject data = new JsonObject();
        data.addProperty("action", "read");

        Api api = RetrofitClient.getClient().create(Api.class);
        Call<JsonObject> call = api.performAction(data);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful() && response.body() != null) {
                    JsonObject jsonResponse = response.body();
                    String status = jsonResponse.get("status").getAsString();
                    if (status.equals("success")) {
                        JsonArray productsArray = jsonResponse.get("products").getAsJsonArray();
                        for (int i = 0; i < productsArray.size(); i++) {
                            JsonObject productJson = productsArray.get(i).getAsJsonObject();
                            Product product = new Product(
                                    productJson.get("id").getAsInt(),
                                    productJson.get("name").getAsString(),
                                    productJson.get("description").getAsString(),
                                    productJson.get("price").getAsInt(),
                                    productJson.get("image_url").getAsString()  // Lấy URL của ảnh
                            );
                            productList.add(product);
                        }
                        productAdapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(getActivity(), "Error: " + jsonResponse.get("message").getAsString(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getActivity(), "Failed to fetch products", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(getActivity(), "Failed: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
