package com.example.asm.Fragment;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.asm.Adapter.HomeAdapter;
import com.example.asm.Client.RetrofitClient;
import com.example.asm.Interface.Api;
import com.example.asm.Model.Product;
import com.example.asm.R;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchFragment extends Fragment {

    private EditText etSearch;
    private Button btnSearch;
    private TextView tvNoResults;
    private RecyclerView rvSearchResults;
    private HomeAdapter searchAdapter;
    private List<Product> searchResults;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        etSearch = view.findViewById(R.id.etSearch);
        btnSearch = view.findViewById(R.id.btnSearch);
        tvNoResults = view.findViewById(R.id.tvNoResults);
        rvSearchResults = view.findViewById(R.id.rvSearchResults);

        rvSearchResults.setLayoutManager(new GridLayoutManager(getActivity(), 2));
        searchResults = new ArrayList<>();
        searchAdapter = new HomeAdapter(searchResults, new HomeAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Product product) {
                openProductDetailFragment(view, product);
            }
        });
        rvSearchResults.setAdapter(searchAdapter);

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performSearch();
            }
        });

        return view;
    }

    private void performSearch() {
        String query = etSearch.getText().toString().trim();
        if (TextUtils.isEmpty(query)) {
            Toast.makeText(getActivity(), "Vui lòng nhập từ khóa tìm kiếm", Toast.LENGTH_SHORT).show();
            return;
        }

        JsonObject data = new JsonObject();
        data.addProperty("action", "search");
        data.addProperty("query", query);

        Api api = RetrofitClient.getClient().create(Api.class);
        Call<JsonObject> call = api.performAction(data);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful() && response.body() != null) {
                    JsonObject jsonResponse = response.body();
                    String status = jsonResponse.get("status").getAsString();
                    if (status.equals("success")) {
                        JsonArray productsArray = jsonResponse.get("products").getAsJsonArray();
                        searchResults.clear();
                        if (productsArray.size() == 0) {
                            tvNoResults.setVisibility(View.VISIBLE);
                        } else {
                            tvNoResults.setVisibility(View.GONE);
                            for (int i = 0; i < productsArray.size(); i++) {
                                JsonObject productJson = productsArray.get(i).getAsJsonObject();
                                Product product = new Product(
                                        productJson.get("id").getAsInt(),
                                        productJson.get("name").getAsString(),
                                        productJson.get("description").getAsString(),
                                        productJson.get("price").getAsInt(),
                                        productJson.get("image_url").getAsString()
                                );
                                searchResults.add(product);
                            }
                            searchAdapter.notifyDataSetChanged();
                            etSearch.setText("");
                        }
                    } else {
                        Toast.makeText(getActivity(), "Error: " + jsonResponse.get("message").getAsString(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getActivity(), "Failed to fetch search results", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(getActivity(), "Failed: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void openProductDetailFragment(View view, Product product) {
        NavController navController = Navigation.findNavController(view);
        Bundle bundle = new Bundle();
        bundle.putSerializable("product", product);
        navController.navigate(R.id.productDetailFragment, bundle);
    }
}
