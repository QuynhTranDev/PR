package com.example.asm.Interface;
import com.example.asm.Client.ApiResponse;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface Api {
    @Headers("Content-Type: application/json")
    @POST("product.php")
    Call<JsonObject> performAction(@Body JsonObject action);

    @FormUrlEncoded
    @POST("add_to_cart.php")
    Call<ApiResponse> addToCart(
            @Field("product_id") int productId,
            @Field("name") String name,
            @Field("description") String description,
            @Field("price") int price,
            @Field("image_url") String imageUrl,
            @Field("user_id") int userId
    );
}
