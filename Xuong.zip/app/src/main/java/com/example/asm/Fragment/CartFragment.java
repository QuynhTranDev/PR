//package com.example.asm.Fragment;
//
//import android.os.Bundle;
//import androidx.annotation.NonNull;
//import androidx.annotation.Nullable;
//import androidx.fragment.app.Fragment;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//
//import com.example.asm.Adapter.CartAdapter;
//import com.example.asm.Manager.CartManager;
//import com.example.asm.Model.Product;
//import com.example.asm.R;
//
//import java.util.List;
//
//public class CartFragment extends Fragment {
//
//    private RecyclerView recyclerView;
//    private CartAdapter cartAdapter;
//    private CartManager cartManager;
//
//    @Nullable
//    @Override
//    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        View view = inflater.inflate(R.layout.fragment_cart, container, false);
//
//        recyclerView = view.findViewById(R.id.recyclerViewCart);
//        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
//
//        cartManager = new CartManager(getContext());
//        List<Product> cart = cartManager.getCart();
//
//        cartAdapter = new CartAdapter(cart);
//        recyclerView.setAdapter(cartAdapter);
//
//        return view;
//    }
//}
