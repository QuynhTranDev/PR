package com.example.asm.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.asm.Client.RetrofitClient;
import com.example.asm.Interface.Api;
import com.example.asm.R;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DeleteProductFragment extends Fragment {

    private EditText etId;
    private Button btnDeleteProduct;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_delete_product, container, false);

        etId = view.findViewById(R.id.etId);
        btnDeleteProduct = view.findViewById(R.id.btnDeleteProduct);

        btnDeleteProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteProduct();
            }
        });

        return view;
    }

    private void deleteProduct() {
        String idString = etId.getText().toString().trim();

        if (idString.isEmpty()) {
            etId.setError("ID cannot be empty");
            return;
        }
        int id = Integer.parseInt(idString);

        JsonObject data = new JsonObject();
        data.addProperty("action", "delete");
        data.addProperty("id", id);

        Api api = RetrofitClient.getClient().create(Api.class);
        Call<JsonObject> call = api.performAction(data);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful() && response.body() != null) {
                    JsonObject jsonResponse = response.body();
                    String status = jsonResponse.get("status").getAsString();
                    if (status.equals("success")) {
                        Toast.makeText(getActivity(), "Product deleted successfully", Toast.LENGTH_SHORT).show();
                        etId.setText("");
                    } else {
                        Toast.makeText(getActivity(), "Error: " + jsonResponse.get("message").getAsString(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getActivity(), "Failed to delete product", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(getActivity(), "Failed: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
