package com.example.asm.Fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.example.asm.LoginActivity;
import com.example.asm.R;

public class ProfileFragment extends Fragment {

    private ImageView profileImage;
    private TextView tvName, tvEmail, tvChangeProfile, tvSignOut;

    @SuppressLint("MissingInflatedId")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        profileImage = view.findViewById(R.id.profile_image);
        tvName = view.findViewById(R.id.tv_name);
        tvEmail = view.findViewById(R.id.tv_email);
        tvChangeProfile = view.findViewById(R.id.tv_change_profile);
        tvSignOut = view.findViewById(R.id.tv_sign_out);
        // Lấy thông tin người dùng từ SharedPreferences
        SharedPreferences prefs = getActivity().getSharedPreferences("user_prefs", getActivity().MODE_PRIVATE);
        String name = prefs.getString("username", "");
        String email = prefs.getString("email", "");
        String imageUrl = prefs.getString("imageUrl", "");

        tvName.setText(name);
        tvEmail.setText(email);
        if (!imageUrl.isEmpty()) {
            Glide.with(this).load(imageUrl).into(profileImage);
        }
        tvChangeProfile.setOnClickListener(v -> openEditProfileFragment(v));

        tvSignOut.setOnClickListener(v -> signOut());

        getParentFragmentManager().setFragmentResultListener("editProfile", this, (requestKey, result) -> {
            String updatedName = result.getString("name");
            String updatedEmail = result.getString("email");
            String updatedImageUrl = result.getString("imageUrl");

            if (updatedName != null) {
                tvName.setText(updatedName);
                prefs.edit().putString("username", updatedName).apply();
            }
            if (updatedEmail != null) {
                tvEmail.setText(updatedEmail);
                prefs.edit().putString("email", updatedEmail).apply();
            }
            if (updatedImageUrl != null) {
                Glide.with(this).load(updatedImageUrl).into(profileImage);
                prefs.edit().putString("imageUrl", updatedImageUrl).apply();
            }
        });

        return view;
    }

    private void openEditProfileFragment(View view) {
        NavController navController = Navigation.findNavController(view);
        navController.navigate(R.id.navigation_profile_edit);
    }

    private void signOut() {
        // Xóa thông tin người dùng khỏi SharedPreferences
        SharedPreferences prefs = getActivity().getSharedPreferences("user_prefs", getActivity().MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.clear(); // Xóa toàn bộ dữ liệu trong SharedPreferences
        editor.apply();

        // Điều hướng về màn hình đăng nhập
        Intent intent = new Intent(getActivity(), LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Xóa ngăn xếp của các Activity hiện tại
        startActivity(intent);
        getActivity().finish(); // Đóng Activity hiện tại
    }

}
