//package com.example.asm.Adapter;
//
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ImageView;
//import android.widget.TextView;
//
//import androidx.annotation.NonNull;
//import androidx.recyclerview.widget.RecyclerView;
//
//import com.example.asm.Model.Product;
//import com.example.asm.R;
//import com.squareup.picasso.Picasso;
//
//import java.util.List;
//
//public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {
//
//    private List<Product> cart;
//
//    public CartAdapter(List<Product> cart) {
//        this.cart = cart;
//    }
//
//    @NonNull
//    @Override
//    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cart, parent, false);
//        return new CartViewHolder(view);
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
//        Product product = cart.get(position);
//        holder.tvName.setText(product.getName());
//        holder.tvDescription.setText(product.getDescription());
//        holder.tvPrice.setText(String.format("%,.0f đ", product.getPrice()));
//        Picasso.get().load(product.getImageUrl()).into(holder.ivProductImage);
//    }
//
//    @Override
//    public int getItemCount() {
//        return cart.size();
//    }
//
//    public static class CartViewHolder extends RecyclerView.ViewHolder {
//
//        ImageView ivProductImage;
//        TextView tvName, tvDescription, tvPrice;
//
//        public CartViewHolder(@NonNull View itemView) {
//            super(itemView);
//            ivProductImage = itemView.findViewById(R.id.ivProductImage);
//            tvName = itemView.findViewById(R.id.tvName);
//            tvDescription = itemView.findViewById(R.id.tvDescription);
//            tvPrice = itemView.findViewById(R.id.tvPrice);
//        }
//    }
//}
