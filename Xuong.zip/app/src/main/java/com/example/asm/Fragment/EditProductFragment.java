package com.example.asm.Fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.asm.Client.RetrofitClient;
import com.example.asm.Interface.Api;
import com.example.asm.R;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditProductFragment extends Fragment {

    private EditText etId, etName, etDescription, etPrice, etImageUrl;  // Thêm EditText cho URL của ảnh
    private Button btnEditProduct;

    @SuppressLint("MissingInflatedId")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_edit_product, container, false);

        etId = view.findViewById(R.id.etId);
        etName = view.findViewById(R.id.etName);
        etDescription = view.findViewById(R.id.etDescription);
        etPrice = view.findViewById(R.id.etPrice);
        etImageUrl = view.findViewById(R.id.etImageUrl);  // Khai báo EditText cho URL của ảnh
        btnEditProduct = view.findViewById(R.id.btnEditProduct);

        btnEditProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editProduct();
            }
        });

        return view;
    }

    private void editProduct() {
        String idString = etId.getText().toString().trim();
        String name = etName.getText().toString().trim();
        String description = etDescription.getText().toString().trim();
        String priceString = etPrice.getText().toString().trim();
        String imageUrl = etImageUrl.getText().toString().trim();  // Lấy URL của ảnh

        if (idString.isEmpty()) {
            etId.setError("ID cannot be empty");
            return;
        }
        int id = Integer.parseInt(idString);

        if (name.isEmpty()) {
            etName.setError("Name cannot be empty");
            return;
        }
        if (description.isEmpty()) {
            etDescription.setError("Description cannot be empty");
            return;
        }
        if (priceString.isEmpty()) {
            etPrice.setError("Price cannot be empty");
            return;
        }
        int price = Integer.parseInt(priceString);

        if (imageUrl.isEmpty()) {
            etImageUrl.setError("Image URL cannot be empty");
            return;
        }

        JsonObject data = new JsonObject();
        data.addProperty("action", "update");
        data.addProperty("id", id);
        data.addProperty("name", name);
        data.addProperty("description", description);
        data.addProperty("price", price);
        data.addProperty("image_url", imageUrl);  // Thêm URL của ảnh

        Api api = RetrofitClient.getClient().create(Api.class);
        Call<JsonObject> call = api.performAction(data);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful() && response.body() != null) {
                    JsonObject jsonResponse = response.body();
                    String status = jsonResponse.get("status").getAsString();
                    if (status.equals("success")) {
                        Toast.makeText(getActivity(), "Product updated successfully", Toast.LENGTH_SHORT).show();
                        etId.setText("");
                        etName.setText("");
                        etDescription.setText("");
                        etPrice.setText("");
                        etImageUrl.setText("");  // Reset EditText cho URL của ảnh
                    } else {
                        Toast.makeText(getActivity(), "Error: " + jsonResponse.get("message").getAsString(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getActivity(), "Failed to update product", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(getActivity(), "Failed: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
