package com.example.asm.Fragment;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.example.asm.Adapter.BannerAdapter;
import com.example.asm.Adapter.HomeAdapter;
import com.example.asm.Client.RetrofitClient;
import com.example.asm.Interface.Api;
import com.example.asm.Model.Product;
import com.example.asm.R;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment {

    private ViewPager viewPager;
    private BannerAdapter bannerAdapter;
    private List<String> bannerImages;
    private RecyclerView recyclerView;
    private HomeAdapter productAdapter;
    private List<Product> productList;
    private TextView textViewBelowBanner;
    private Handler handler;
    private Runnable runnable;
    private int currentPage = 0;
    private ImageView ivCart;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        viewPager = view.findViewById(R.id.viewPager);
        textViewBelowBanner = view.findViewById(R.id.textViewBelowBanner);
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 2));
        bannerImages = new ArrayList<>();
        bannerAdapter = new BannerAdapter(getActivity(), bannerImages);
        viewPager.setAdapter(bannerAdapter);
        ivCart = view.findViewById(R.id.ivCart);
        productList = new ArrayList<>();
        productAdapter = new HomeAdapter(productList, new HomeAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Product product) {
                openProductDetailFragment(view, product);
            }
        });
        recyclerView.setAdapter(productAdapter);

        ivCart.setOnClickListener(v -> navigateToCartFragment(v));

        fetchBannerImages();
        fetchProducts();

        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                if (currentPage == bannerImages.size()) {
                    currentPage = 0;
                }
                viewPager.setCurrentItem(currentPage++, true);
                handler.postDelayed(this, 9000);
            }
        };
        handler.post(runnable);

        return view;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        handler.removeCallbacks(runnable);
    }

    private void fetchBannerImages() {
        // Add your banner image URLs here
        bannerImages.add("https://marketplace.canva.com/EAFloAOrGBY/1/0/1600w/canva-orange-and-black-minimalist-food-banner-landscape-hvZzaUttSLk.jpg");
        bannerImages.add("https://i.ytimg.com/vi/vz2zGfaq1ec/maxresdefault.jpg");
        bannerImages.add("https://images01.nicepage.com/a1389d7bc73adea1e1c1fb7e/f55c87d06a345e9c94021f3e/3007283.jpg");

        bannerAdapter.notifyDataSetChanged();
    }

    private void fetchProducts() {
        JsonObject data = new JsonObject();
        data.addProperty("action", "read");

        Api api = RetrofitClient.getClient().create(Api.class);
        Call<JsonObject> call = api.performAction(data);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful() && response.body() != null) {
                    JsonObject jsonResponse = response.body();
                    String status = jsonResponse.get("status").getAsString();
                    if (status.equals("success")) {
                        JsonArray productsArray = jsonResponse.get("products").getAsJsonArray();
                        if (productsArray.size() == 0) {
                            textViewBelowBanner.setText("Không có sản phẩm");
                        } else {
                            textViewBelowBanner.setText("");
                            for (int i = 0; i < productsArray.size(); i++) {
                                JsonObject productJson = productsArray.get(i).getAsJsonObject();
                                Product product = new Product(
                                        productJson.get("id").getAsInt(),
                                        productJson.get("name").getAsString(),
                                        productJson.get("description").getAsString(),
                                        productJson.get("price").getAsInt(),
                                        productJson.get("image_url").getAsString()
                                );
                                productList.add(product);
                            }
                            productAdapter.notifyDataSetChanged();
                        }
                    } else {
                        Toast.makeText(getActivity(), "Error: " + jsonResponse.get("message").getAsString(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getActivity(), "Failed to fetch products", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(getActivity(), "Failed: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void openProductDetailFragment(View view, Product product) {
        NavController navController = Navigation.findNavController(view);
        Bundle bundle = new Bundle();
        bundle.putSerializable("product", product);
        navController.navigate(R.id.productDetailFragment, bundle);
    }

    private void navigateToCartFragment(View view) {
        NavController navController = Navigation.findNavController(view);
        navController.navigate(R.id.navigation_cart);
    }
}
